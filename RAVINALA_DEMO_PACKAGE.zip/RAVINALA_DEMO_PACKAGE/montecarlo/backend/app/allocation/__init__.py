"""Allocation persistence helpers package."""
